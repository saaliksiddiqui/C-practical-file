#include <stdio.h>

int main() {
    // Basic details
    char name[] = "MUHAMMAD SAALIK";
    int age = 18;
    char gender[] = "Male";
    char address[] = "Mayur vihar phase 1";
    char phone[] = "9999999";
    char email[] = "saaliksiddiqui0099@email.com";
    
    // Education
    char degree[] = "Bachelor of Computer and Applications";
    char university[] = "St.Andrews Institute of Technology and Management";
    int graduation_year = 2024;
    
    // Print biodata
    printf("Biodata:\n\n");
    printf("Name: %s\n", name);
    printf("Age: %d\n", age);
    printf("Gender: %s\n", gender);
    printf("Address: %s\n", address);
    printf("Phone: %s\n", phone);
    printf("Email: %s\n\n", email);
    
    printf("Education:\n\n");
    printf("Degree: %s\n", degree);
    printf("University: %s\n", university);
    printf("Graduation year: %d\n\n", graduation_year);    

    
    return 0;
}
