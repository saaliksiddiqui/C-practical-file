#include <stdio.h>

int main() {
    int num1, num2;
    printf("Enter two integers: ");
    scanf("%d %d", &num1, &num2);
    
    // Perform addition, subtraction, multiplication, and division
    if (num1 > 0 && num2 > 0) {
        int sum = num1 + num2;
        printf("Sum: %d\n", sum);
        
        int diff = num1 - num2;
        printf("Difference: %d\n", diff);
        
        int prod = num1 * num2;
        printf("Product: %d\n", prod);
        
        int quot = num1 / num2;
        printf("Quotient: %d\n", quot);
    } else {
        printf("Please enter positive integers.\n");
    }
    
    return 0;
}
