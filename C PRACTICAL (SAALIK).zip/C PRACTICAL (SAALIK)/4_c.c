#include <stdio.h>

int main() {
    int num, fact = 1, i;

    printf("Enter a positive integer: ");
    scanf("%d", &num);

    // factorial of 0 and 1 is 1
    if (num == 0 || num == 1) {
        printf("The factorial of %d is: 1\n", num);
    }
    else {
        for (i = 2; i <= num; i++) {
            fact *= i;
        }
        printf("The factorial of %d is: %d\n", num, fact);
    }

    return 0;
}
