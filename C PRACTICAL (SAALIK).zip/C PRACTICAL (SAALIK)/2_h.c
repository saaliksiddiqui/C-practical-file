#include <stdio.h>

int main() {
    double d = 3.14159;
    int i = (int) d;
    printf("The double value %f converted to an int is %d\n", d, i);
    return 0;
}
