#include <stdio.h>

int main() {
    int num, i;

    printf("Enter a number: ");
    scanf("%d", &num);

    printf("Multiplication table using while loop:\n");
    i = 1;
    while(i <= 10) {
        printf("%d x %d = %d\n", num, i, num * i);
        i++;
    }

    printf("Multiplication table using do-while loop:\n");
    i = 1;
    do {
        printf("%d x %d = %d\n", num, i, num * i);
        i++;
    } while(i <= 10);

    printf("Multiplication table using for loop:\n");
    for(i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", num, i, num * i);
    }

    return 0;
}
