#include <stdio.h>

int main() {
    int num, reverse = 0, remainder;

    printf("Enter a number: ");
    scanf("%d", &num);

    do {
        remainder = num % 10; // get the last digit of the number
        reverse = reverse * 10 + remainder; // add the last digit to the reverse number
        num /= 10; // remove the last digit from the number
    } while (num != 0);

    printf("The reverse of the number is: %d\n", reverse);

    return 0;
}
