#include <stdio.h>

int main() {
    int integerVar;
    float floatVar;
    double doubleVar;
    char charVar;

    printf("Size of integer variable: %ld bytes\n", sizeof(integerVar));
    printf("Size of float variable: %ld bytes\n", sizeof(floatVar));
    printf("Size of double variable: %ld bytes\n", sizeof(doubleVar));
    printf("Size of character variable: %ld bytes\n", sizeof(charVar));

    return 0;
}
