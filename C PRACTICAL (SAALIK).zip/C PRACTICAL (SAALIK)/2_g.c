#include <stdio.h>

int main() {
    int num = 65; // ASCII code for 'A'
    char ch = (char) num;
    printf("The ASCII value %d converted to a character is %c\n", num, ch);

    return 0;
}
