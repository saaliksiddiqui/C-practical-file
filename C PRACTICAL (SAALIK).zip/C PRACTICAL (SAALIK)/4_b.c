#include <stdio.h>

int main() {
    int num, sum = 0;

    printf("Enter numbers to add (enter 0 to exit):\n");

    // using while loop
    while(1) {
        scanf("%d", &num);
        if(num == 0)
            break;
        sum += num;
    }

    printf("Sum using while loop: %d\n", sum);

    // resetting the sum
    sum = 0;
    
    printf("Enter numbers to add (enter 0 to exit):\n");

    // using do-while loop
    do {
        scanf("%d", &num);
        if(num != 0)
            sum += num;
    } while(num != 0);

    printf("Sum using do-while loop: %d\n", sum);

    return 0;
}
