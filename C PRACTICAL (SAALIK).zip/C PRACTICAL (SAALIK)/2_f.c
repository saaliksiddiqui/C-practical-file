#include <stdio.h>

#define PI 3.14159

int main() {
    float radius, perimeter, area;

    printf("Enter the radius of the circle: ");
    scanf("%f", &radius);

    perimeter = 2 * PI * radius;
    area = PI * radius * radius;

    printf("Perimeter of the circle = %f units\n", perimeter);
    printf("Area of the circle = %f square units\n", area);

    return 0;
}
